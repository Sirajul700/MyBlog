
package com.tech.blog.helper;
import java.sql.*;
public class ConnectionProvider {
    private static Connection con;

    public static Connection connectionto() {
     try{
    
              Class.forName("com.mysql.jdbc.Driver");
      
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tachblog","root","");
     
            if(con!=null){
            System.err.println("connection establishmed");
            return con;
            }else{
            System.err.println("connection  is not establishmed");
            
            }
    
    }catch(ClassNotFoundException ex){
    
        System.err.println(ex.getMessage());
    }catch (SQLException ex){
    
    }
    return null;
    }
}
